# School Management System Backend – Audit Report

## Scope and limits
This audit is based on the backend source files supplied in `school-management-system.zip`.
No Postman/API execution was performed, as requested. A JavaScript syntax check was performed
on the revised source files. This is a code review, not a production certification.

## Preserved
- Existing Node.js / Express / Mongoose architecture.
- Existing installed package versions and package-lock.json.
- Existing model and route naming conventions.
- Existing multi-school and multi-branch data model.
- Existing JWT and bcryptjs authentication approach.
- Existing successful API paths and response shapes where possible.

## Corrections applied
1. Removed duplicate `schoolCode` index declaration in `School.js`; the field-level unique index remains.
2. Added centralized Express error middleware and registered it after routes and the 404 handler.
3. Added rate limiting to the authentication route group.
4. Added configurable credentialed CORS using `CLIENT_URL`; localhost defaults apply in development.
5. Added request body size limits.
6. Improved registration/login input type checks and password length bounds.
7. Added target-account hierarchy checks before user update/deactivation, preventing users from modifying their own account through management endpoints or changing higher-privilege accounts.
8. Corrected profile factory's explicit branch/student reference errors to return HTTP 400 rather than generic HTTP 500.
9. Allowed a logged-in student to reach the student profile GET route; the profile controller scopes non-managers to their own profile.
10. Replaced the empty `.env.example` with variable names and safe placeholders only.

## Important design findings still requiring a product decision
1. **Super Admin provisioning:** The current app has a `super_admin` role but no safe bootstrap/first-super-admin provisioning workflow. Do not create a Super Admin through public registration.
2. **School/Owner provisioning flow:** Current public registration creates an Owner with `school: null`; Owner then creates one School. The current Super Admin `createUser` path expects a school ID and assigns it to the Owner, which conflicts with that Owner self-service school-creation flow. Decide whether Super Admin creates schools and assigns owners, or owners self-register and create schools.
3. **Parent-child verification:** Parent profile accepts student profile IDs belonging to the same school. The database has no verified guardian/relationship evidence field or invitation/approval workflow. Same-school validation is not proof of parenthood.
4. **Profile lifecycle:** User account creation and profile creation are separate operations. A user may exist without its matching role profile. Consider a single service/transaction workflow.
5. **Branch access policy:** User records have branch assignments, but most list/profile controllers currently scope by school rather than restricting every query to the user's assigned branches. Define branch-level access requirements before enabling branch-sensitive screens.
6. **Student/Teacher own profile update:** Factory limits non-manager updates to a small self-editable field list. Route/controller behavior should be revisited when frontend profile-edit requirements are finalized.
7. **Email uniqueness:** `User.email` is globally unique. This means the same email cannot create accounts in multiple schools. Confirm this is intended for the SaaS product.
8. **School owner uniqueness:** Controller prevents an owner from creating a second school, but the database does not enforce a unique `School.owner` index. Add a unique index only after checking existing database records for duplicates.
9. **Cookie production deployment:** `SameSite=None` requires HTTPS and credentialed CORS. Set `CLIENT_URL` to the exact frontend origin(s) in production.
10. **No automated test suite:** `npm test` is currently a placeholder. Tests and API verification remain a later phase.

## Not included in this ZIP
Academic classes/sections/subjects, attendance, fees, exams, timetable, reports, notifications, file uploads,
frontend panels, deployment configuration, and production monitoring.

## Verification performed
- Inspected all supplied backend JavaScript files and package metadata.
- Ran `node --check` against revised JavaScript files.
- Did not connect to the user's MongoDB instance.
- Did not run API requests or Postman tests.
- Did not modify the user's live database or original uploaded ZIP.

## Before deployment
- Set strong unique `JWT_SECRET` and production `MONGODB_URI`.
- Set `NODE_ENV=production` and exact `CLIENT_URL`.
- Configure HTTPS, database backups, logging/monitoring and secret management.
- Resolve the design decisions above and write automated integration tests.
