
const mongoose = require("mongoose");

const Branch = require("../models/Branch");
const School = require("../models/School");
const StudentProfile = require("../models/StudentProfile");
const User = require("../models/User");

const createProfileController = (
  Model,
  targetRole,
  allowedFields,
  creatorRoles
) => {
  // Get school ID according to logged-in user's role
  const getSchoolId = (req) => {
    if (req.user.roles.includes("super_admin")) {
      return (
        req.params.schoolId ||
        req.body.schoolId ||
        req.query.schoolId
      );
    }

    return req.user.school;
  };

  // Check whether user can manage profiles
  const canManage = (req) => {
    return (
      req.user.roles.some((role) => creatorRoles.includes(role)) ||
      req.user.roles.includes("super_admin")
    );
  };

  // Handle errors
  const handleError = (res, error) => {
    console.error("Profile Controller Error:", error);

    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message: "This record already exists.",
      });
    }

    if (
      error.name === "ValidationError" ||
      error.name === "CastError" ||
      (Number.isInteger(error.statusCode) && error.statusCode < 500)
    ) {
      return res.status(400).json({
        success: false,
        message: error.message,
      });
    }

    return res.status(500).json({
      success: false,
      message: "Internal server error.",
    });
  };

  // Validate school
  const validateSchool = async (schoolId) => {
    if (!schoolId || !mongoose.Types.ObjectId.isValid(schoolId)) {
      return false;
    }

    const school = await School.findOne({
      _id: schoolId,
      status: "active",
    });

    return Boolean(school);
  };

  // Only allow approved fields
  const filterFields = (data, fields = allowedFields) => {
    const filteredData = {};

    fields.forEach((field) => {
      if (data[field] !== undefined) {
        filteredData[field] = data[field];
      }
    });

    return filteredData;
  };

  // Validation errors created by this factory should be returned as client errors.
  const validationError = (message) => {
    const error = new Error(message);
    error.statusCode = 400;
    return error;
  };

  // Validate branch and student references
  const validateReferences = async (data, schoolId) => {
    if (data.branch !== undefined && data.branch !== null) {
      if (!mongoose.Types.ObjectId.isValid(data.branch)) {
        throw validationError("Invalid branch ID.");
      }

      const branch = await Branch.findOne({
        _id: data.branch,
        school: schoolId,
        status: "active",
      });

      if (!branch) {
        throw validationError(
          "Branch not found or does not belong to this school."
        );
      }
    }

    if (data.branches !== undefined) {
      if (!Array.isArray(data.branches)) {
        throw validationError("Branches must be an array.");
      }

      if (data.branches.some((id) => typeof id !== "string" && !mongoose.isValidObjectId(id))) {
        throw validationError("Every branch must have a valid ID.");
      }

      const uniqueBranches = [
        ...new Set(data.branches.map((id) => String(id))),
      ];

      for (const id of uniqueBranches) {
        if (!mongoose.Types.ObjectId.isValid(id)) {
          throw validationError("Invalid branch ID.");
        }
      }

      const branches = await Branch.find({
        _id: { $in: uniqueBranches },
        school: schoolId,
        status: "active",
      });

      if (branches.length !== uniqueBranches.length) {
        throw validationError(
          "One or more branches are invalid or do not belong to this school."
        );
      }

      data.branches = uniqueBranches;
    }

    if (data.students !== undefined) {
      if (!Array.isArray(data.students)) {
        throw validationError("Students must be an array.");
      }

      if (data.students.some((id) => typeof id !== "string" && !mongoose.isValidObjectId(id))) {
        throw validationError("Every student must have a valid ID.");
      }

      const uniqueStudents = [
        ...new Set(data.students.map((id) => String(id))),
      ];

      for (const id of uniqueStudents) {
        if (!mongoose.Types.ObjectId.isValid(id)) {
          throw validationError("Invalid student ID.");
        }
      }

      const students = await StudentProfile.find({
        _id: { $in: uniqueStudents },
        school: schoolId,
      });

      if (students.length !== uniqueStudents.length) {
        throw validationError(
          "One or more students are invalid or do not belong to this school."
        );
      }

      data.students = uniqueStudents;
    }

    return true;
  };

  // CREATE PROFILE
  const createProfile = async (req, res) => {
    try {
      if (!canManage(req)) {
        return res.status(403).json({
          success: false,
          message: "You are not allowed to create this profile.",
        });
      }

      const schoolId = getSchoolId(req);

      if (!(await validateSchool(schoolId))) {
        return res.status(400).json({
          success: false,
          message:
            "Valid active school is required. Super Admin must provide schoolId.",
        });
      }

      const { user: userId } = req.body;

      if (!userId || !mongoose.Types.ObjectId.isValid(userId)) {
        return res.status(400).json({
          success: false,
          message: "Valid user ID is required.",
        });
      }

      const user = await User.findOne({
        _id: userId,
        school: schoolId,
        status: "active",
      });

      if (!user) {
        return res.status(404).json({
          success: false,
          message: "Active user not found in this school.",
        });
      }

      if (!user.roles.includes(targetRole)) {
        return res.status(400).json({
          success: false,
          message: `User does not have the ${targetRole} role.`,
        });
      }

      const profileData = filterFields(req.body);

      await validateReferences(profileData, schoolId);

      const profile = await Model.create({
        ...profileData,
        user: user._id,
        school: schoolId,
      });

      return res.status(201).json({
        success: true,
        message: `${targetRole} profile created successfully.`,
        data: profile,
      });
    } catch (error) {
      return handleError(res, error);
    }
  };

  // GET PROFILES
  const getProfiles = async (req, res) => {
    try {
      const schoolId = getSchoolId(req);

      if (!(await validateSchool(schoolId))) {
        return res.status(400).json({
          success: false,
          message:
            "Valid active school is required. Super Admin must provide schoolId.",
        });
      }

      const filter = {
        school: schoolId,
      };

      // Non-managers can only see their own profile
      if (!canManage(req)) {
        filter.user = req.user.id;
      }

      const profiles = await Model.find(filter)
        .populate("user", "name email roles")
        .sort({ createdAt: -1 });

      return res.status(200).json({
        success: true,
        count: profiles.length,
        data: profiles,
      });
    } catch (error) {
      return handleError(res, error);
    }
  };

  // UPDATE PROFILE
  const updateProfile = async (req, res) => {
    try {
      const schoolId = getSchoolId(req);

      if (!(await validateSchool(schoolId))) {
        return res.status(400).json({
          success: false,
          message:
            "Valid active school is required. Super Admin must provide schoolId.",
        });
      }

      if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
        return res.status(400).json({
          success: false,
          message: "Invalid profile ID.",
        });
      }

      const profile = await Model.findOne({
        _id: req.params.id,
        school: schoolId,
      });

      if (!profile) {
        return res.status(404).json({
          success: false,
          message: "Profile not found.",
        });
      }

      const isOwnProfile =
        profile.user.toString() === req.user.id;

      const manager = canManage(req);

      if (!manager && !isOwnProfile) {
        return res.status(403).json({
          success: false,
          message: "You are not allowed to update this profile.",
        });
      }

      // Users can only edit their own basic information
      const selfEditableFields = [
        "phone",
        "address",
        "bloodGroup",
        "occupation",
        "emergencyContact",
      ];

      const fieldsToUpdate = manager
        ? allowedFields
        : allowedFields.filter((field) =>
            selfEditableFields.includes(field)
          );

      const updateData = filterFields(
        req.body,
        fieldsToUpdate
      );

      await validateReferences(updateData, schoolId);

      Object.assign(profile, updateData);

      await profile.save();

      return res.status(200).json({
        success: true,
        message: `${targetRole} profile updated successfully.`,
        data: profile,
      });
    } catch (error) {
      return handleError(res, error);
    }
  };

  return {
    createProfile,
    getProfiles,
    updateProfile,
  };
};

module.exports = createProfileController;
