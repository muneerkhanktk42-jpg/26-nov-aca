
const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      maxlength: 100,
    },

    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      maxlength: 150,
    },

    password: {
      type: String,
      required: true,
      minlength: 8,
      select: false,
    },

    phone: {
      type: String,
      trim: true,
    },

    roles: {
      type: [
        {
          type: String,
          enum: [
            "super_admin",
            "owner",
            "principal",
            "admin",
            "teacher",
            "student",
            "parent",
          ],
        },
      ],
      required: true,
      validate: [
        {
          validator: function (roles) {
            return Array.isArray(roles) && roles.length > 0;
          },
          message: "At least one role is required.",
        },
        {
          validator: function (roles) {
            return new Set(roles).size === roles.length;
          },
          message: "Duplicate roles are not allowed.",
        },
      ],
    },

    school: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "School",
      default: null,
    },

    branches: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Branch",
      },
    ],

    status: {
      type: String,
      enum: ["active", "inactive", "suspended"],
      default: "active",
    },
  },
  {
    timestamps: true,
  }
);

// Normalize email
userSchema.pre("save", function () {
  if (this.email) {
    this.email = this.email.toLowerCase().trim();
  }
});

// Prevent duplicate branch assignments
userSchema.pre("save", function () {
  if (this.isModified("branches")) {
    this.branches = [
      ...new Map(
        this.branches.map((id) => [id.toString(), id])
      ).values(),
    ];
  }
});

const User = mongoose.model("User", userSchema);

module.exports = User;
