
const express = require("express");
const router = express.Router();

const {
  createSchool,
  getMySchool,
  updateSchool,
  getAllSchools,
  updateSchoolStatus,
} = require("../controllers/schoolController");

const {
  getOwnerDashboard,
} = require("../controllers/ownerDashboardController");

const { protect } = require("../middlewares/authMiddleware");
const { authorizeRoles } = require("../middlewares/roleMiddleware");

router.use(protect);

// ==================================
// OWNER DASHBOARD
// ==================================

router.get(
  "/owner-dashboard",
  authorizeRoles("owner"),
  getOwnerDashboard
);

// ==================================
// SCHOOL MANAGEMENT
// ==================================

// Create School
router.post(
  "/",
  authorizeRoles("owner"),
  createSchool
);

// Get My School
router.get(
  "/my-school",
  authorizeRoles("owner"),
  getMySchool
);

// Get All Schools
router.get(
  "/",
  authorizeRoles("super_admin"),
  getAllSchools
);

// Update School
router.put(
  "/:id",
  authorizeRoles("owner", "super_admin"),
  updateSchool
);

// Update School Status
router.patch(
  "/:id/status",
  authorizeRoles("super_admin"),
  updateSchoolStatus
);

module.exports = router;
