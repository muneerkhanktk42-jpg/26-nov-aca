
const express = require("express");
const router = express.Router();

const {
  createProfile,
  getProfiles,
  updateProfile,
} = require("../controllers/teacherController");

const { protect } = require("../middlewares/authMiddleware");
const { authorizeRoles } = require("../middlewares/roleMiddleware");

router.use(protect);

router.post(
  "/",
  authorizeRoles("owner", "principal", "admin", "super_admin"),
  createProfile
);

router.get(
  "/",
  authorizeRoles("owner", "principal", "admin", "teacher", "super_admin"),
  getProfiles
);

router.put(
  "/:id",
  authorizeRoles("owner", "principal", "admin", "teacher", "super_admin"),
  updateProfile
);

module.exports = router;
