
const express = require("express");
const router = express.Router();

const {
  createProfile,
  getProfiles,
  updateProfile,
} = require("../controllers/principalController");

const { protect } = require("../middlewares/authMiddleware");
const { authorizeRoles } = require("../middlewares/roleMiddleware");

router.use(protect);

router.post(
  "/",
  authorizeRoles("owner", "super_admin"),
  createProfile
);

router.get(
  "/",
  authorizeRoles("owner", "principal", "super_admin"),
  getProfiles
);

router.put(
  "/:id",
  authorizeRoles("owner", "principal", "super_admin"),
  updateProfile
);

module.exports = router;
