
const express = require("express");
const router = express.Router();

const {
  createProfile,
  getProfiles,
  updateProfile,
} = require("../controllers/studentController");

const { protect } = require("../middlewares/authMiddleware");
const { authorizeRoles } = require("../middlewares/roleMiddleware");

router.use(protect);

// Create student profile
router.post(
  "/",
  authorizeRoles("owner", "principal", "admin"),
  createProfile
);

// Get student profiles
router.get(
  "/",
  authorizeRoles("owner", "principal", "admin", "teacher", "student"),
  getProfiles
);

// Update student profile
router.put(
  "/:id",
  authorizeRoles("owner", "principal", "admin"),
  updateProfile
);

module.exports = router;
