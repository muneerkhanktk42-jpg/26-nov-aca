
const express = require("express");
const router = express.Router();

const {
  createBranch,
  getBranches,
  getBranchById,
  updateBranch,
  deleteBranch,
} = require("../controllers/branchController");

const { protect } = require("../middlewares/authMiddleware");
const { authorizeRoles } = require("../middlewares/roleMiddleware");

router.use(protect);

// Create Branch
router.post(
  "/",
  authorizeRoles("owner", "super_admin"),
  createBranch
);

// Get All Branches
router.get(
  "/",
  authorizeRoles("owner", "principal", "admin", "super_admin"),
  getBranches
);

// Get Single Branch
router.get(
  "/:id",
  authorizeRoles("owner", "principal", "admin", "super_admin"),
  getBranchById
);

// Update Branch
router.put(
  "/:id",
  authorizeRoles("owner", "super_admin"),
  updateBranch
);

// Delete (Deactivate) Branch
router.delete(
  "/:id",
  authorizeRoles("owner", "super_admin"),
  deleteBranch
);

module.exports = router;
