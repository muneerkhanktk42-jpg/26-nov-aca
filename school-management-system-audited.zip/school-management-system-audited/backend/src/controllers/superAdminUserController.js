
const mongoose = require("mongoose");
const User = require("../models/User");
const School = require("../models/School");

const ALLOWED_ROLES = [
  "owner",
  "principal",
  "admin",
  "teacher",
  "student",
  "parent",
];

const ALLOWED_STATUSES = ["active", "inactive", "suspended"];

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 10;
const MAX_LIMIT = 100;

const escapeRegex = (value) =>
  value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// ======================================
// GET ALL USERS (ALL SCHOOLS)
// ======================================

exports.getAllUsers = async (req, res, next) => {
  try {
    // PAGE VALIDATION
    const requestedPage = parseInt(req.query.page, 10);

    const page =
      Number.isInteger(requestedPage) && requestedPage > 0
        ? requestedPage
        : DEFAULT_PAGE;

    // LIMIT VALIDATION
    const requestedLimit = parseInt(req.query.limit, 10);

    let limit = DEFAULT_LIMIT;

    if (Number.isInteger(requestedLimit) && requestedLimit > 0) {
      limit = Math.min(requestedLimit, MAX_LIMIT);
    }

    const { search, role, status, schoolId } = req.query;

    // Base filter: Exclude Super Admin accounts
    const filter = {
      roles: { $in: ALLOWED_ROLES },
    };

    // SEARCH FILTER
    if (search && search.trim()) {
      const searchRegex = new RegExp(
        escapeRegex(search.trim()),
        "i"
      );

      const matchingSchools = await School.find({
        name: searchRegex,
      })
        .select("_id")
        .lean();

      const matchingSchoolIds = matchingSchools.map(
        (school) => school._id
      );

      filter.$or = [
        { name: searchRegex },
        { email: searchRegex },
        { phone: searchRegex },
        { school: { $in: matchingSchoolIds } },
      ];
    }

    // ROLE FILTER
    if (role) {
      if (!ALLOWED_ROLES.includes(role)) {
        return res.status(400).json({
          success: false,
          message: "Invalid user role",
        });
      }

      filter.roles = role;
    }

    // STATUS FILTER
    if (status) {
      if (!ALLOWED_STATUSES.includes(status)) {
        return res.status(400).json({
          success: false,
          message: "Invalid user status",
        });
      }

      filter.status = status;
    }

    // SCHOOL FILTER
    if (schoolId) {
      if (!mongoose.isValidObjectId(schoolId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid school ID",
        });
      }

      filter.school = schoolId;
    }

    // PAGINATION
    const skip = (page - 1) * limit;

    const [users, total] = await Promise.all([
      User.find(filter)
        .select("-password")
        .populate("school", "name schoolCode")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),

      User.countDocuments(filter),
    ]);

    return res.status(200).json({
      success: true,
      count: users.length,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
        hasNextPage: page * limit < total,
        hasPrevPage: page > 1,
      },
      users,
    });
  } catch (error) {
    next(error);
  }
};

// ======================================
// GET SINGLE USER DETAILS
// ======================================

exports.getUserDetails = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid user ID",
      });
    }

    const user = await User.findOne({
      _id: id,
      roles: { $in: ALLOWED_ROLES },
    })
      .select("-password")
      .populate("school", "name schoolCode status")
      .populate("branches", "name branchCode status")
      .lean();

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    return res.status(200).json({
      success: true,
      user,
    });
  } catch (error) {
    next(error);
  }
};

// ======================================
// UPDATE USER STATUS
// ======================================

exports.updateUserStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid user ID",
      });
    }

    if (!ALLOWED_STATUSES.includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Status must be active, inactive, or suspended",
      });
    }

    const user = await User.findOne({
      _id: id,
      roles: { $in: ALLOWED_ROLES },
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    user.status = status;
    await user.save();

    const updatedUser = await User.findById(user._id)
      .select("-password")
      .populate("school", "name schoolCode")
      .lean();

    return res.status(200).json({
      success: true,
      message: "User status updated successfully",
      user: updatedUser,
    });
  } catch (error) {
    next(error);
  }
};
