
const mongoose = require("mongoose");
const User = require("../models/User");

const ALLOWED_ROLES = [
  "owner",
  "principal",
  "admin",
  "teacher",
  "student",
  "parent",
];

const ALLOWED_STATUSES = ["active", "inactive", "suspended"];

const escapeRegex = (value) =>
  value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

// ======================================
// GET ALL USERS
// ======================================
exports.getAllUsers = async (req, res, next) => {
  try {
    const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
    const limit = Math.min(
      Math.max(parseInt(req.query.limit, 10) || 10, 1),
      100
    );

    const { search, role, status, schoolId } = req.query;

    const filter = {
      roles: { $in: ALLOWED_ROLES },
    };

    // Search by name, email or phone
    if (search && search.trim()) {
      const searchRegex = new RegExp(escapeRegex(search.trim()), "i");

      filter.$or = [
        { name: searchRegex },
        { email: searchRegex },
        { phone: searchRegex },
      ];
    }

    // Filter by role
    if (role) {
      if (!ALLOWED_ROLES.includes(role)) {
        return res.status(400).json({
          success: false,
          message: "Invalid user role",
        });
      }

      filter.roles = { $in: [role] };
    }

    // Filter by status
    if (status) {
      if (!ALLOWED_STATUSES.includes(status)) {
        return res.status(400).json({
          success: false,
          message: "Invalid user status",
        });
      }

      filter.status = status;
    }

    // Filter by school
    if (schoolId) {
      if (!mongoose.isValidObjectId(schoolId)) {
        return res.status(400).json({
          success: false,
          message: "Invalid school ID",
        });
      }

      filter.school = schoolId;
    }

    const skip = (page - 1) * limit;

    const [users, total] = await Promise.all([
      User.find(filter)
        .select("-password")
        .populate("school", "name schoolCode")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),

      User.countDocuments(filter),
    ]);

    return res.status(200).json({
      success: true,
      count: users.length,
      pagination: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
        hasNextPage: page * limit < total,
        hasPrevPage: page > 1,
      },
      users,
    });
  } catch (error) {
    next(error);
  }
};

// ======================================
// GET SINGLE USER DETAILS
// ======================================
exports.getUserDetails = async (req, res, next) => {
  try {
    const { id } = req.params;

    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid user ID",
      });
    }

    const user = await User.findOne({
      _id: id,
      roles: { $in: ALLOWED_ROLES },
    })
      .select("-password")
      .populate("school", "name schoolCode status")
      .populate("branches", "name branchCode status")
      .lean();

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    return res.status(200).json({
      success: true,
      user,
    });
  } catch (error) {
    next(error);
  }
};

// ======================================
// UPDATE USER STATUS
// ======================================
exports.updateUserStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid user ID",
      });
    }

    if (!ALLOWED_STATUSES.includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Status must be active, inactive, or suspended",
      });
    }

    const user = await User.findOne({
      _id: id,
      roles: { $in: ALLOWED_ROLES },
    });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    user.status = status;
    await user.save();

    const updatedUser = await User.findById(user._id)
      .select("-password")
      .populate("school", "name schoolCode")
      .lean();

    return res.status(200).json({
      success: true,
      message: "User status updated successfully",
      user: updatedUser,
    });
  } catch (error) {
    next(error);
  }
};
