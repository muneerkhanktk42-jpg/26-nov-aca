
const Branch = require("../models/Branch");
const School = require("../models/School");
const mongoose = require("mongoose");

const getSchoolId = (req) => {
  if (req.user.roles.includes("super_admin")) {
    return req.params.schoolId || req.body.schoolId || req.query.schoolId;
  }

  return req.user.school;
};

const hasManagementRole = (req) => {
  return req.user.roles.some((role) =>
    ["owner", "principal", "admin", "super_admin"].includes(role)
  );
};

// =====================================
// CREATE BRANCH
// =====================================

exports.createBranch = async (req, res, next) => {
  try {
    if (!hasManagementRole(req)) {
      return res.status(403).json({
        success: false,
        message: "Not authorized to create branches",
      });
    }

    const schoolId = getSchoolId(req);
    const { name, branchCode, email, phone, address } = req.body;

    if (!schoolId || !mongoose.isValidObjectId(schoolId)) {
      return res.status(400).json({
        success: false,
        message: "Valid school ID is required",
      });
    }

    if (!name || !branchCode || !phone || !address) {
      return res.status(400).json({
        success: false,
        message: "Name, branch code, phone and address are required",
      });
    }

    const school = await School.findById(schoolId);

    if (!school || school.status !== "active") {
      return res.status(404).json({
        success: false,
        message: "Active school not found",
      });
    }

    if (
      !req.user.roles.includes("super_admin") &&
      school._id.toString() !== req.user.school?.toString()
    ) {
      return res.status(403).json({
        success: false,
        message: "This school does not belong to your account",
      });
    }

    const branch = await Branch.create({
      school: schoolId,
      name,
      branchCode,
      email,
      phone,
      address,
    });

    res.status(201).json({
      success: true,
      message: "Branch created successfully",
      branch,
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message: "Branch code already exists in this school",
      });
    }

    next(error);
  }
};

// =====================================
// GET ALL BRANCHES
// =====================================

exports.getBranches = async (req, res, next) => {
  try {
    if (!hasManagementRole(req)) {
      return res.status(403).json({
        success: false,
        message: "Not authorized",
      });
    }

    const schoolId = getSchoolId(req);

    if (!schoolId || !mongoose.isValidObjectId(schoolId)) {
      return res.status(400).json({
        success: false,
        message: "Valid school ID is required",
      });
    }

    const branches = await Branch.find({ school: schoolId })
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: branches.length,
      branches,
    });
  } catch (error) {
    next(error);
  }
};

// =====================================
// GET SINGLE BRANCH
// =====================================

exports.getBranchById = async (req, res, next) => {
  try {
    if (!hasManagementRole(req)) {
      return res.status(403).json({
        success: false,
        message: "Not authorized to view this branch",
      });
    }

    const { id } = req.params;
    const schoolId = getSchoolId(req);

    if (!mongoose.isValidObjectId(id)) {
      return res.status(400).json({
        success: false,
        message: "Invalid branch ID",
      });
    }

    if (!schoolId || !mongoose.isValidObjectId(schoolId)) {
      return res.status(400).json({
        success: false,
        message: "Valid school ID is required",
      });
    }

    const branch = await Branch.findOne({
      _id: id,
      school: schoolId,
    });

    if (!branch) {
      return res.status(404).json({
        success: false,
        message: "Branch not found in this school",
      });
    }

    res.status(200).json({
      success: true,
      branch,
    });
  } catch (error) {
    next(error);
  }
};

// =====================================
// UPDATE BRANCH
// =====================================

exports.updateBranch = async (req, res, next) => {
  try {
    if (!hasManagementRole(req)) {
      return res.status(403).json({
        success: false,
        message: "Not authorized",
      });
    }

    const schoolId = getSchoolId(req);
    const { id } = req.params;

    if (
      !mongoose.isValidObjectId(id) ||
      !schoolId ||
      !mongoose.isValidObjectId(schoolId)
    ) {
      return res.status(400).json({
        success: false,
        message: "Valid branch and school IDs are required",
      });
    }

    const branch = await Branch.findOne({
      _id: id,
      school: schoolId,
    });

    if (!branch) {
      return res.status(404).json({
        success: false,
        message: "Branch not found in this school",
      });
    }

    [
      "name",
      "branchCode",
      "email",
      "phone",
      "address",
      "status",
    ].forEach((field) => {
      if (req.body[field] !== undefined) {
        branch[field] = req.body[field];
      }
    });

    await branch.save();

    res.status(200).json({
      success: true,
      message: "Branch updated successfully",
      branch,
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({
        success: false,
        message: "Branch code already exists",
      });
    }

    next(error);
  }
};

// =====================================
// DEACTIVATE BRANCH
// =====================================

exports.deleteBranch = async (req, res, next) => {
  try {
    if (!hasManagementRole(req)) {
      return res.status(403).json({
        success: false,
        message: "Not authorized",
      });
    }

    const schoolId = getSchoolId(req);
    const { id } = req.params;

    if (
      !mongoose.isValidObjectId(id) ||
      !schoolId ||
      !mongoose.isValidObjectId(schoolId)
    ) {
      return res.status(400).json({
        success: false,
        message: "Valid branch and school IDs are required",
      });
    }

    const branch = await Branch.findOneAndUpdate(
      {
        _id: id,
        school: schoolId,
      },
      {
        status: "inactive",
      },
      {
        new: true,
        runValidators: true,
      }
    );

    if (!branch) {
      return res.status(404).json({
        success: false,
        message: "Branch not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Branch deactivated successfully",
      branch,
    });
  } catch (error) {
    next(error);
  }
};
