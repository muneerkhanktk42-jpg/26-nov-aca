
const User = require("../models/User");
const bcrypt = require("bcryptjs");

// ======================================
// GET SUPER ADMIN PROFILE
// ======================================

exports.getMyProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user.id)
      .select("-password")
      .lean();

    if (!user || !user.roles.includes("super_admin")) {
      return res.status(404).json({
        success: false,
        message: "Super Admin not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Profile fetched successfully",
      user,
    });
  } catch (error) {
    next(error);
  }
};

// ======================================
// UPDATE SUPER ADMIN PROFILE
// ======================================

exports.updateMyProfile = async (req, res, next) => {
  try {
    const { name, phone } = req.body;

    if (name === undefined && phone === undefined) {
      return res.status(400).json({
        success: false,
        message: "Please provide name or phone to update",
      });
    }

    if (name !== undefined && (!name || !name.trim())) {
      return res.status(400).json({
        success: false,
        message: "Name cannot be empty",
      });
    }

    const user = await User.findById(req.user.id);

    if (!user || !user.roles.includes("super_admin")) {
      return res.status(404).json({
        success: false,
        message: "Super Admin not found",
      });
    }

    if (name !== undefined) {
      user.name = name.trim();
    }

    if (phone !== undefined) {
      user.phone = phone.trim();
    }

    await user.save();

    return res.status(200).json({
      success: true,
      message: "Profile updated successfully",
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        roles: user.roles,
      },
    });
  } catch (error) {
    next(error);
  }
};

// ======================================
// CHANGE SUPER ADMIN PASSWORD
// ======================================

exports.changeMyPassword = async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        success: false,
        message: "Current password and new password are required",
      });
    }

    if (typeof currentPassword !== "string" ||
        typeof newPassword !== "string") {
      return res.status(400).json({
        success: false,
        message: "Passwords must be valid strings",
      });
    }

    if (newPassword.length < 8) {
      return res.status(400).json({
        success: false,
        message: "New password must be at least 8 characters",
      });
    }

    if (currentPassword === newPassword) {
      return res.status(400).json({
        success: false,
        message: "New password must be different from current password",
      });
    }

    const user = await User.findById(req.user.id)
      .select("+password");

    if (!user || !user.roles.includes("super_admin")) {
      return res.status(404).json({
        success: false,
        message: "Super Admin not found",
      });
    }

    const isPasswordCorrect = await bcrypt.compare(
      currentPassword,
      user.password
    );

    if (!isPasswordCorrect) {
      return res.status(400).json({
        success: false,
        message: "Current password is incorrect",
      });
    }

    user.password = await bcrypt.hash(newPassword, 12);

    await user.save();

    return res.status(200).json({
      success: true,
      message: "Password changed successfully. Please login again.",
    });
  } catch (error) {
    next(error);
  }
};
