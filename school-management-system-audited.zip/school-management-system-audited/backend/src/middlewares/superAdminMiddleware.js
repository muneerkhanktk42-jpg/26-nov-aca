
const superAdminOnly = (req, res, next) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        message: "Authentication required. Please login first.",
      });
    }

    if (
      !Array.isArray(req.user.roles) ||
      !req.user.roles.includes("super_admin")
    ) {
      return res.status(403).json({
        success: false,
        message: "Access denied. Super Admin permission required.",
      });
    }

    next();
  } catch (error) {
    next(error);
  }
};

module.exports = { superAdminOnly };
