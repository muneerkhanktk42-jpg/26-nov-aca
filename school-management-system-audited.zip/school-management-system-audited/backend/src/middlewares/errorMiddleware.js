const errorHandler = (err, req, res, next) => {
  console.error("API Error:", err);

  if (res.headersSent) return next(err);

  if (err.code === 11000) {
    const fields = Object.keys(err.keyPattern || {});
    return res.status(409).json({
      success: false,
      message: fields.length
        ? `Duplicate value for: ${fields.join(", ")}`
        : "A record with this value already exists.",
    });
  }

  if (err.name === "ValidationError" || err.name === "CastError") {
    return res.status(400).json({
      success: false,
      message: err.message,
    });
  }

  const statusCode = Number.isInteger(err.statusCode)
    ? err.statusCode
    : Number.isInteger(err.status)
      ? err.status
      : err.message === "Origin is not allowed by CORS"
        ? 403
        : 500;
  return res.status(statusCode).json({
    success: false,
    message:
      statusCode >= 500 && process.env.NODE_ENV === "production"
        ? "Internal server error."
        : err.message || "Internal server error.",
  });
};

module.exports = errorHandler;
